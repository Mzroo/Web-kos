<!-- Section Kontak -->
<section class="section-kontak py-5 shadow" id="contact" style="background-color: #f1f1f1;">
    <div class="container">
        <h2 class="text-center mb-5">Hubungi Kami</h2>
        <div class="row">
            <!-- Form Kontak -->
            <div class="col-md-6">
                <div class="card shadow-sm p-4">
                    <h5 class="mb-4">Formulir Kontak</h5>
                    <form>
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama" placeholder="Masukkan nama Anda" required />
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Alamat Email</label>
                            <input type="email" class="form-control" id="email" placeholder="Masukkan email Anda" required />
                        </div>
                        <div class="mb-3">
                            <label for="topik" class="form-label">Topik Pesan</label>
                            <select class="form-select" id="topik" required>
                                <option value="">-- Pilih Topik --</option>
                                <option value="pemesanan">Pemesanan</option>
                                <option value="kerjasama">Kerja Sama</option>
                                <option value="komplain">Keluhan</option>
                                <option value="lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="pesan" class="form-label">Pesan</label>
                            <textarea class="form-control" id="pesan" rows="4" placeholder="Tulis pesan Anda..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Kirim Pesan</button>
                        <div class="alert alert-success mt-3 d-none" id="alertBerhasil">
                            Pesan Anda berhasil dikirim!
                        </div>
                    </form>
                </div>
            </div>

            <!-- Info Kontak dan Peta -->
            <div class="col-md-6">
                <div class="card shadow-sm p-4 mb-4">
                    <h5>Informasi Kontak</h5>
                    <p><strong>Alamat:</strong> Jl. Contoh No.123, Kota ABC</p>
                    <p><strong>Email:</strong> contoh@email.com</p>
                    <p><strong>Telepon:</strong> 0812-3456-7890</p>
                    <p><strong>Jam Operasional:</strong> Senin - Jumat, 08.00 - 17.00</p>
                    <div class="mt-3">
                        <a href="https://wa.me/088291227304" class="me-3" target="_blank">
                            <i class="fab fa-whatsapp fa-lg"></i>
                        </a>
                        <a href="mailto:contoh@email.com" class="me-3">
                            <i class="fas fa-envelope fa-lg"></i>
                        </a>
                        <a href="#" class="me-3">
                            <i class="fab fa-instagram fa-lg"></i>
                        </a>
                        <a href="#">
                            <i class="fab fa-facebook fa-lg"></i>
                        </a>
                    </div>
                </div>
                <div class="card shadow-sm p-0">
                    <h5 class="p-3">Lokasi Kami</h5>
                    <iframe
                        width="100%"
                        height="250"
                        frameborder="0"
                        style="border:0"
                        allowfullscreen
                        loading="lazy"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126917.58087490184!2d106.68943031640624!3d-6.229386199999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f157b5e5e109%3A0x301576d14febd70!2sJakarta%2C%20Indonesia!5e0!3m2!1sen!2sid!4v1600000000000"></iframe>
                </div>
            </div>
        </div>
    </div>
</section>