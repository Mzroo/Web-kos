<!-- Section 2 end -->

<!-- Section 3 -->
<!-- Section Fasilitas Kos -->
<section class="bg-fasilitas-section py-5" id="fasilitas">
    <div class="container">
        <h2 class="text-center mb-5">Fasilitas Kos</h2>
        <div class="row text-center">
            <div class="col-md-4 mb-4">
                <div class="p-4 border rounded shadow-sm bg-white">
                    <img
                        src="<?= $main_url ?>asset/img/wifi.png"
                        alt="WiFi"
                        width="60"
                        class="mb-3" />
                    <h5>WiFi Cepat</h5>
                    <p>
                        Akses internet cepat dan stabil, cocok untuk belajar atau kerja
                        online.
                    </p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="p-4 border rounded shadow-sm bg-white">
                    <img
                        src="<?= $main_url ?>asset/img/dapur.png"
                        alt="Dapur"
                        width="60"
                        class="mb-3" />
                    <h5>Dapur Bersama</h5>
                    <p>Fasilitas dapur lengkap untuk kamu yang suka masak sendiri.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="p-4 border rounded shadow-sm bg-white">
                    <img
                        src="<?= $main_url ?>asset/img/laundry.png"
                        alt="Laundry"
                        width="60"
                        class="mb-3" />
                    <h5>Laundry Mandiri</h5>
                    <p>Tempat cuci baju yang bersih dan nyaman, tersedia 24 jam.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- End -->

<!-- Section 4 -->
<!-- Section Testimoni Penghuni -->
<section class="section-4 py-5" id="testimoni">
    <div class="container">
        <h2 class="text-center mb-5">Apa Kata Penghuni?</h2>
        <div class="row justify-content-center">
            <div class="col-md-4 mb-4">
                <div class="card shadow border-0 h-100">
                    <div class="card-body text-center">
                        <img
                            src="<?= $main_url ?>asset/img/penghuni1.jfif"
                            alt="Penghuni 1"
                            class="rounded-circle mb-3"
                            width="80"
                            height="80" />
                        <h5 class="card-title">Rina Aulia</h5>
                        <p class="card-text">
                            "Kosnya nyaman banget, fasilitas lengkap, dan ibu kos sangat
                            ramah. Lokasi juga strategis."
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card shadow border-0 h-100">
                    <div class="card-body text-center">
                        <img
                            src="<?= $main_url ?>asset/img/penghuni2.jfif"
                            alt="Penghuni 2"
                            class="rounded-circle mb-3"
                            width="80"
                            height="80" />
                        <h5 class="card-title">Dimas Prasetyo</h5>
                        <p class="card-text">
                            "Saya sudah tinggal di sini lebih dari 1 tahun. Nyaman dan
                            aman, cocok untuk mahasiswa."
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card shadow border-0 h-100">
                    <div class="card-body text-center">
                        <img
                            src="<?= $main_url ?>asset/img/penghuni3.jfif"
                            alt="Penghuni 3"
                            class="rounded-circle mb-3"
                            width="80"
                            height="80" />
                        <h5 class="card-title">Lestari Widya</h5>
                        <p class="card-text">
                            "Lingkungannya tenang dan bersih. Ada dapur bersama dan WiFi
                            cepat. Recommended!"
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>