<!-- Navbar -->
<nav
    class="navbar navbar-expand-lg bg-dark navbar-dark fixed-top py-3 shadow">
    <div class="container">
        <a href="<?= $main_url ?>user/dasboard.php" class="navbar-brand d-flex align-items-center">
            <img src="<?= $main_url ?>asset/img/Logo.png" alt="Logo Kos Ku" style="height:90px; margin-top:-20px; margin-bottom:-20px;">
        </a>

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navmenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a href="#" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="#kamar" class="nav-link">Kamar</a>
                </li>
                <li class="nav-item">
                    <a href="#contact" class="nav-link">Contact</a>
                </li>
                <li class="nav-item">
                    <a href="login.php" class="nav-link text-white w-100 text-center shadow border border-black ms-2 h-100 rounded-3 btn btn-primary">Login</a>
                </li>
            </ul>
        </div>
    </div>
</nav>