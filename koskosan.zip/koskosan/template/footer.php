  <!-- Footer -->
  <footer class="bg-dark text-white py-4 shadow">
      <div class="container text-center">
          <p class="mb-2">&copy; <?= date('Y') ?> KosKu. All rights reserved.</p>
          <div>
              <a href="#" class="text-white me-3 text-decoration-none">Privacy Policy</a>
              <a href="#" class="text-white text-decoration-none">Terms of Service</a>
          </div>
      </div>
  </footer>
  <script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>

  </html>