  <!-- Header Section -->
  <header class="bg-dark text-white text-center text-lg-start mt-5 pt-5">
    <div class="container py-5">
      <div class="row align-items-center">
        <div class="col-lg-6 mb-4 mb-lg-0">
          <h1 class="display-4 fw-bold">Selamat Datang di Stay Kost</h1>
          <p class="lead">
            Temukan kamar kos terbaik, nyaman, dan sesuai kebutuhanmu hanya di
            satu tempat!
          </p>
          <a href="#kamar" class="btn btn-primary btn-lg mt-3">Lihat Kamar</a>
        </div>
        <div class="col-lg-6">
          <img
            src="<?= $main_url ?>asset/img/kamar.jpg"
            alt="Ilustrasi Kos"
            class="img-fluid rounded shadow" />
        </div>
      </div>
    </div>
  </header>

  <!-- Header end -->