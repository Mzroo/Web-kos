<?php
include_once "config/koneksi.php";
$title = "StayKost";
include_once "template/header.php";
include_once "template/navbar.php";
include_once "template/section1.php";
?>

<body>

  <!-- Section 2 -->

  <section class="py-5 section-2-index" id="kamar">
    <div class="container">
      <h2 class="text-black mb-5 text-center">Daftar Kamar Kos</h2>

      <?php
      $per_page = 3; // jumlah kamar per halaman
      $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
      $start = ($page - 1) * $per_page;

      // Ambil semua kamar (tanpa filter jenis)
      $query = "SELECT * FROM kamar LIMIT ?, ?";
      $stmt = $koneksi->prepare($query);
      $stmt->bind_param("ii", $start, $per_page);
      $stmt->execute();
      $result = $stmt->get_result();

      // Hitung total data
      $total_query = "SELECT COUNT(*) as total FROM kamar";
      $total_result = mysqli_query($koneksi, $total_query);
      $total_data = mysqli_fetch_assoc($total_result)['total'];
      $total_pages = ceil($total_data / $per_page);

      if ($result->num_rows > 0) {
        echo "<div class='row'>";
        while ($data = $result->fetch_assoc()) {
          echo "
           <div class='col-md-4 mb-4'>
            <div class='card shadow h-100'>
                <img src='img/{$data['gambar']}' class='card-img-top' alt='{$data['nama_kamar']}' style='height:200px; object-fit:cover;'>
                <div class='card-body d-flex flex-column'>
                    <h5 class='card-title'>{$data['nama_kamar']}</h5>
                    <p class='card-text flex-grow-1'>{$data['deskripsi']}</p>
                    <div class='d-flex gap-2 mb-2 flex-wrap'>
                        <span class='badge bg-secondary'>{$data['jenis_kos']}</span>
                        <span class='badge bg-info'>{$data['fasilitas']}</span>
                        <span class='badge bg-success'>{$data['status']}</span>
                    </div>
                    <p class='text-primary fw-bold'>Rp " . number_format($data['harga'], 0, ',', '.') . "/bulan</p>
                    <a href='login.php' class='btn btn-primary mt-auto'>Lihat Detail</a>
                </div>
            </div>
        </div>";
        }
        echo "</div>";

        // Pagination
        if ($total_pages > 1) {
          echo '<nav aria-label="Page navigation" class="mt-4"><ul class="pagination justify-content-center">';

          if ($page > 1) {
            $prev = $page - 1;
            echo "<li class='page-item'><a class='page-link' href='?page=$prev#kamar'>&laquo;</a></li>";
          }

          for ($i = 1; $i <= $total_pages; $i++) {
            $active = ($i == $page) ? 'active' : '';
            echo "<li class='page-item $active'><a class='page-link' href='?page=$i#kamar'>$i</a></li>";
          }

          if ($page < $total_pages) {
            $next = $page + 1;
            echo "<li class='page-item'><a class='page-link' href='?page=$next#kamar'>&raquo;</a></li>";
          }

          echo '</ul></nav>';
        }
      } else {
        echo "<p class='text-muted'>Belum ada data kamar tersedia.</p>";
      }
      ?>
    </div>
  </section>

  <?php
  include_once "template/fasilitas.php";
  include_once "template/kontak.php";
  include_once "template/footer.php";
  ?>