<?php
include_once '../config/koneksi.php';
$title = 'Lihat Kamar';
include_once 'template/header.php';
include_once 'template/navbar.php';
include_once 'template/slidebar.php';

// Tangani pencarian
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';
$limit = 4; // jumlah data per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Hitung total data
$count_query = "SELECT COUNT(*) AS total FROM kamar";
if (!empty($search)) {
    $count_query .= " WHERE nama_kamar LIKE '%$search%' OR jenis_kos LIKE '%$search%' OR tipe_kamar LIKE '%$search%'";
}
$count_result = mysqli_query($koneksi, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_data / $limit);


$query = "SELECT * FROM kamar";
if (!empty($search)) {
    $query .= " WHERE nama_kamar LIKE '%$search%' OR jenis_kos LIKE '%$search%' OR tipe_kamar LIKE '%$search%'";
}
$query .= " LIMIT $start, $limit";
$result = mysqli_query($koneksi, $query);

?>

<!-- Main Content -->
<div class="content" id="layoutSidenav_content">
    <main class="mb-5">
        <div class="container-fluid px-4">
            <h1 class="mt-1">Lihat Semua Data Kamar</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-door-open me-2"></i>Data Semua Kamar
                    </h5>
                    <form method="GET" action="" class="d-flex" style="max-width: 300px;">
                        <input type="text" name="search" class="form-control form-control-sm me-2" placeholder="Cari kamar..." value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-sm btn-primary" type="submit">Cari</button>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle" style="font-size: 13px;">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Kamar</th>
                                    <th>Jenis Kos</th>
                                    <th>Tipe Kamar</th>
                                    <th>Alamat</th>
                                    <th>Deskripsi</th>
                                    <th>Status</th>
                                    <th>Gambar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = $start + 1;
                                while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                    <tr>
                                        <td class="text-center"><?= $no++ ?></td>
                                        <td><?= $row['nama_kamar'] ?></td>
                                        <td><?= $row['jenis_kos'] ?></td>
                                        <td><?= $row['tipe_kamar'] ?></td>
                                        <td><?= $row['alamat'] ?></td>
                                        <td><?= $row['deskripsi'] ?></td>
                                        <td><?= $row['status'] ?></td>
                                        <td class="text-center">
                                            <img src="../img/<?= $row['gambar'] ?>" width="80" alt="Gambar Kamar">
                                        </td>
                                        <td class="text-center">
                                            <a href="crud/edit.php?id=<?= $row['id_kamar'] ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="crud/delete.php?id=<?= $row['id_kamar'] ?>"
                                                class="btn btn-danger btn-sm"
                                                onclick="return confirm('Yakin ingin menghapus kamar ini?');">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <?php if ($total_data === 0): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">Data tidak ditemukan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Page -->
                    <?php if ($total_data > 4): ?>
                        <!-- Pagination -->
                        <nav aria-label="...">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $page - 1 ?>">Previous</a>
                                    </li>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                                        <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $page + 1 ?>">Next</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>
</div>

<?php
include_once 'template/footer.php';
?>