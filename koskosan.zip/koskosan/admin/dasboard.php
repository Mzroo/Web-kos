<?php
session_start();

include_once '../config/koneksi.php';
$title = 'admin koskosan';
include_once 'template/header.php';
include_once 'template/navbar.php';
include_once 'template/slidebar.php';

?>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Dashboard</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
            <div class="row g-4">
                <!-- Card Total Kamar -->
                <?php
                $query = "SELECT COUNT(*) AS total_kamar FROM kamar";
                $result = mysqli_query($koneksi, $query);
                $data = mysqli_fetch_assoc($result);
                $total_kamar = $data['total_kamar'];
                ?>

                <div class="col-md-4">
                    <div class="card text-bg-primary shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-bed me-2"></i>Total Kamar</h5>
                            <hr class="bg-secondary">
                            <p class="card-text fs-3"><?php echo $total_kamar; ?></p>
                        </div>
                    </div>
                </div>


                <!-- Card Total Pengguna -->
                <?php
                $query = "SELECT COUNT(*) AS total_user FROM user WHERE role = 'user'";
                $result = mysqli_query($koneksi, $query);
                $data = mysqli_fetch_assoc($result);
                $total_user = $data['total_user'];
                ?>

                <div class="col-md-4">
                    <div class="card text-bg-success shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-users me-2"></i>Total Pengguna</h5>
                            <hr class="bg-secondary">
                            <p class="card-text fs-3"><?php echo $total_user; ?></p>
                        </div>
                    </div>
                </div>


                <!-- Card Total Booking -->
                <?php

                $query = "SELECT COUNT(*) AS total_booking FROM booking b
                            JOIN user u ON b.id_user = u.id_user
                            WHERE u.role = 'user'";
                $result = mysqli_query($koneksi, $query);
                $data = mysqli_fetch_assoc($result);
                $total_booking = $data['total_booking'];

                ?>

                <div class="col-md-4">
                    <div class="card text-bg-warning shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-calendar-check me-2"></i>Total Booking</h5>
                            <hr class="bg-secondary">
                            <p class="card-text fs-3"><?php echo $total_booking ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
</div>

<?php
include_once 'template/footer.php';
?>