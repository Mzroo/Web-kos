<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= $main_url ?>asset/img/icon.jpeg">
    <link href="<?= $main_url ?>asset/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?= $main_url ?>asset/fontawesome/css/all.min.css">

</head>