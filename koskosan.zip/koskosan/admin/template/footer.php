<footer class="py-4 bg-dark text-light mt-auto">
    <div class="container text-center">
        <p class="mb-2">&copy; <?= date('Y') ?> KosKu. All rights reserved.</p>
    </div>
</footer>
<script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= $main_url ?>admin/js/script.js"></script>
</body>

</html>