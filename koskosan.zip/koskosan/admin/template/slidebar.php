        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <li class="nav-item"><a href="<?= $main_url ?>admin/dasboard.php" class="nav-link active"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>

                            <div class="sb-sidenav-menu-heading">Interface</div>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-door-open me-2"></i></div>
                                Data Kamar

                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <li><a href="tambah.php" class="nav-link"><i class="fas fa-plus me-2"></i>Tambah Kamar</a></li>
                                    <li><a href="<?= $main_url ?>admin/lihat.php" class="nav-link"><i class="fas fa-list me-2"></i>Lihat Semua</a></li>
                                </nav>
                            </div>

                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseBooking" aria-expanded="false" aria-controls="collapseBooking">
                                <div class="sb-nav-link-icon"><i class="fas fa-book me-2"></i></div>
                                Booking

                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseBooking" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <li><a href="<?= $main_url ?>admin/booking.php" class="nav-link"><i class="fas fa-calendar-check me-1"></i>Konfirmasi Booking</a></li>
                                    <li><a href="<?= $main_url ?>admin/konfirmasi_pembayaran.php" class="nav-link"><i class="fas fa-wallet me-1"></i>konfir pembayaran</a></li>
                                </nav>
                            </div>



                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                            </div>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        Admin Kos
                    </div>
                </nav>
            </div>