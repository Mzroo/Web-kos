<?php
session_start();
include '../config/koneksi.php';
$title = 'Konfirmasi Pembayaran';
include_once 'template/header.php';
include_once 'template/navbar.php';
include_once 'template/slidebar.php';

// Cek admin
if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    echo "<script>alert('Akses ditolak!'); window.location='../login.php';</script>";
    exit;
}

// Ambil data semua pembayaran
$query = mysqli_query($koneksi, "
    SELECT b.*, u.nama AS nama_user, k.nama_kamar 
    FROM booking b
    JOIN user u ON b.id_user = u.id_user
    JOIN kamar k ON b.id_kamar = k.id_kamar
    ORDER BY b.tanggal_booking DESC
");
?>

<!-- Layout Content -->
<div id="layoutSidenav_content">
    <main class="mb-5">
        <div class="container-fluid px-4">
            <h1 class="mt-1">Konfirmasi Pembayaran</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard / Pembayaran</li>
            </ol>
            <div class="card shadow mb-4">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-credit-card me-2"></i>Data Pembayaran</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle" style="font-size: 13px;">
                            <thead class="table-light text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Nama User</th>
                                    <th>Nama Kamar</th>
                                    <th>Metode</th>
                                    <th>Total Bayar</th>
                                    <th>Bukti Transfer</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1;
                                while ($row = mysqli_fetch_assoc($query)) : ?>
                                    <tr>
                                        <td class="text-center"><?= $no++; ?></td>
                                        <td><?= htmlspecialchars($row['nama_user']); ?></td>
                                        <td><?= htmlspecialchars($row['nama_kamar']); ?></td>
                                        <td><?= $row['metode_pembayaran']; ?></td>
                                        <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.'); ?></td>
                                        <td class="text-center">
                                            <?php if (!empty($row['bukti_transfer'])) : ?>
                                                <a href="../user/bukti/<?= $row['bukti_transfer']; ?>" target="_blank" class="btn btn-sm btn-info">Lihat</a>
                                            <?php else : ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?php
                                            if ($row['status_pembayaran'] === 'sudah bayar') {
                                                echo '<span class="badge bg-success">Dikonfirmasi</span>';
                                            } elseif ($row['status_pembayaran'] === 'pending') {
                                                echo '<span class="badge bg-warning text-dark">Menunggu</span>';
                                            } elseif ($row['status_pembayaran'] === 'belum bayar') {
                                                echo '<span class="badge bg-danger">Ditolak</span>';
                                            } else {
                                                echo '<span class="badge bg-secondary">Tidak diketahui</span>';
                                            }
                                            ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if ($row['status_pembayaran'] === 'pending') : ?>
                                                <a href="konfirmasi_pembayaran.php?terima=<?= $row['id_booking']; ?>" class="btn btn-sm btn-success mb-1">
                                                    <i class="fas fa-check"></i> Terima
                                                </a>
                                                <a href="konfirmasi_pembayaran.php?tolak=<?= $row['id_booking']; ?>" class="btn btn-sm btn-danger mb-1" onclick="return confirm('Yakin tolak pembayaran ini?')">
                                                    <i class="fas fa-times"></i> Tolak
                                                </a>
                                                <a href="konfirmasi_pembayaran.php?hapus=<?= $row['id_booking']; ?>" class="btn btn-sm btn-outline-dark" onclick="return confirm('Yakin hapus data booking ini?')">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </a>
                                            <?php else : ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                                <?php if (mysqli_num_rows($query) == 0) : ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Tidak ada data booking.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= $main_url ?>admin/js/script.js"></script>

<?php
// Proses aksi
if (isset($_GET['terima'])) {
    $id = intval($_GET['terima']);
    mysqli_query($koneksi, "UPDATE booking SET status_pembayaran = 'sudah bayar', status = 'diterima' WHERE id_booking = $id");
    echo "<script>window.location='konfirmasi_pembayaran.php';</script>";
    exit;
}

if (isset($_GET['tolak'])) {
    $id = intval($_GET['tolak']);
    mysqli_query($koneksi, "UPDATE booking SET status_pembayaran = 'belum bayar', bukti_transfer = NULL WHERE id_booking = $id");
    echo "<script>window.location='konfirmasi_pembayaran.php';</script>";
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $get = mysqli_query($koneksi, "SELECT bukti_transfer FROM booking WHERE id_booking = $id");
    $data = mysqli_fetch_assoc($get);

    if (!empty($data['bukti_transfer']) && file_exists("../user/bukti/" . $data['bukti_transfer'])) {
        unlink("../user/bukti/" . $data['bukti_transfer']);
    }

    mysqli_query($koneksi, "DELETE FROM booking WHERE id_booking = $id");
    echo "<script>window.location='konfirmasi_pembayaran.php';</script>";
    exit;
}
?>
