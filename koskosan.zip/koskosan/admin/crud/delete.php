<?php
include_once '../../config/koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus gambar terlebih dahulu jika disimpan di server (opsional)
    $queryGet = mysqli_query($koneksi, "SELECT gambar FROM kamar WHERE id_kamar = '$id'");
    $data = mysqli_fetch_assoc($queryGet);
    if ($data && file_exists('../uploads/' . $data['gambar'])) {
        unlink('../uploads/' . $data['gambar']);
    }

    // Hapus data dari database
    $query = mysqli_query($koneksi, "DELETE FROM kamar WHERE id_kamar = '$id'");

    if ($query) {
        echo "<script>window.location.href='../lihat.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data!'); window.location.href='../admin/kamar.php';</script>";
    }
} else {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='../admin/kamar.php';</script>";
}
