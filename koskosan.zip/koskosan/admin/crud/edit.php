<?php
// koneksi
include_once '../../config/koneksi.php';

// ambil id dari URL, jika tidak ada redirect kembali
if (!isset($_GET['id'])) {
    header('Location: ../lihat.php');
    exit;
}
$id = intval($_GET['id']);

// ambil data lama
$result = mysqli_query($koneksi, "SELECT * FROM kamar WHERE id_kamar = $id");
$row = mysqli_fetch_assoc($result);

// proses update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = $_POST['nama_kamar'];
    $jenis     = $_POST['jenis_kos'];
    $tipe      = $_POST['tipe_kamar'];
    $alamat    = $_POST['alamat'];
    $harga     = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];

    // cek upload gambar baru
    if (!empty($_FILES['gambar']['name'])) {
        // hapus gambar lama
        if (!empty($row['gambar']) && file_exists('../../img/' . $row['gambar'])) {
            unlink('../../img/' . $row['gambar']);
        }
        $gambar = $_FILES['gambar']['name'];
        move_uploaded_file($_FILES['gambar']['tmp_name'], '../../img/' . $gambar);
        $sql = "UPDATE kamar SET 
                  nama_kamar='$nama',
                  jenis_kos='$jenis',
                  tipe_kamar='$tipe',
                  alamat='$alamat',
                  harga=$harga,
                  deskripsi='$deskripsi',
                  gambar='$gambar'
                WHERE id_kamar=$id";
    } else {
        $sql = "UPDATE kamar SET 
                  nama_kamar='$nama',
                  jenis_kos='$jenis',
                  tipe_kamar='$tipe',
                  alamat='$alamat',
                  harga=$harga,
                  deskripsi='$deskripsi'
                WHERE id_kamar=$id";
    }

    mysqli_query($koneksi, $sql);
    header('Location: ../lihat.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kamar</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Edit Data Kamar</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Nama Kamar</label>
                                <input type="text" name="nama_kamar" class="form-control" value="<?= htmlspecialchars($row['nama_kamar']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Jenis Kos</label>
                                <select name="jenis_kos" class="form-select" required>
                                    <option value="Putra" <?= $row['jenis_kos'] == 'Putra' ? 'selected' : '' ?>>Putra</option>
                                    <option value="Putri" <?= $row['jenis_kos'] == 'Putri' ? 'selected' : '' ?>>Putri</option>
                                    <option value="Campuran" <?= $row['jenis_kos'] == 'Campuran' ? 'selected' : '' ?>>Campuran</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Tipe Kamar</label>
                                <input type="text" name="tipe_kamar" class="form-control" value="<?= htmlspecialchars($row['tipe_kamar']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Alamat</label>
                                <textarea name="alamat" class="form-control" rows="2" required><?= htmlspecialchars($row['alamat']) ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Harga (Rp)</label>
                                <input type="number" name="harga" class="form-control" value="<?= $row['harga'] ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" rows="3" required><?= htmlspecialchars($row['deskripsi']) ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Gambar Saat Ini</label><br>
                                <?php if (!empty($row['gambar'])): ?>
                                    <img src="../../img/<?= $row['gambar'] ?>" class="img-thumbnail mb-2" width="150">
                                <?php endif; ?>
                                <label class="form-label">Ganti Gambar (opsional)</label>
                                <input type="file" name="gambar" class="form-control" accept="image/*">
                            </div>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-save me-1"></i>Simpan Perubahan
                            </button>
                            <a href="../lihat.php" class="btn btn-secondary ms-2">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>