<?php
include '../../config/koneksi.php';
session_start();


$id_booking = $_GET['id_booking'];
$aksi = $_GET['aksi']; // 'terima' atau 'tolak'

if ($aksi === 'terima') {
    mysqli_query($koneksi, "UPDATE booking SET status = 'diterima' WHERE id_booking = $id_booking");

    // Opsional: ubah status kamar jadi "terisi"
    $result = mysqli_query($koneksi, "SELECT id_kamar FROM booking WHERE id_booking = $id_booking");
    $data = mysqli_fetch_assoc($result);
    mysqli_query($koneksi, "UPDATE kamar SET status = 'terisi' WHERE id_kamar = {$data['id_kamar']}");
} elseif ($aksi === 'tolak') {
    mysqli_query($koneksi, "UPDATE booking SET status = 'ditolak' WHERE id_booking = $id_booking");
}

header("Location: ../booking.php");
