<?php
include_once '../../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $nama_kamar  = $_POST['nama_kamar'];
    $jenis_kos   = $_POST['jenis_kos'];
    $tipe_kamar  = $_POST['tipe_kamar'];
    $alamat      = $_POST['alamat'];
    $harga       = $_POST['harga'];
    $deskripsi   = $_POST['deskripsi'];
    $fasilitas   = $_POST['fasilitas'];
    $status      = $_POST['status'];

    // proses upload gambar
    $gambar_name = $_FILES['gambar']['name'];
    $gambar_tmp  = $_FILES['gambar']['tmp_name'];

    // pindahkan gambar ke folder ../img/
    move_uploaded_file($gambar_tmp, '../../img/' . $gambar_name);

    // insert ke database
    $query = "INSERT INTO kamar (nama_kamar, jenis_kos, tipe_kamar, alamat, harga, deskripsi, fasilitas, status, gambar)
              VALUES ('$nama_kamar', '$jenis_kos', '$tipe_kamar', '$alamat', '$harga', '$deskripsi', '$fasilitas','$status', '$gambar_name')";

    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Data kamar berhasil ditambahkan!'); window.location='../dasboard.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data kamar!'); window.location='../tambah_kamar.php';</script>";
    }
}
