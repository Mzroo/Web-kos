<?php
include_once '../config/koneksi.php';
$title = 'Tambah Data Kamar';
include_once 'template/header.php';
include_once 'template/navbar.php';
include_once 'template/slidebar.php';
?>

<div id="layoutSidenav_content">
    <div class="d-flex flex-column min-vh-100">
        <main class="flex-grow-1">
            <div class="container-fluid">
                <h2 class="mb-4"><i class="fas fa-tachometer-alt me-2"></i>Tambah Data Kamar</h2>
                <div class="row justify-content-center">
                    <div class="col-md-10 col-lg-8">
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="fas fa-bed me-2"></i>Form Tambah Kamar</h5>
                            </div>
                            <div class="card-body">
                                <form action="crud/proses_tambah.php" method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label>Nama Kamar</label>
                                        <input type="text" name="nama_kamar" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Jenis Kos</label>
                                        <select name="jenis_kos" class="form-select" required>
                                            <option value="">-- Pilih Jenis --</option>
                                            <option value="Putra">Putra</option>
                                            <option value="Putri">Putri</option>
                                            <option value="Campuran">Campuran</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Tipe Kamar</label>
                                        <select name="tipe_kamar" class="form-select" required>
                                            <option value="">-- Pilih Tipe Kamar --</option>
                                            <option value="Single">Single</option>
                                            <option value="Double">Double</option>
                                            <option value="Suite">Suite</option>
                                            <option value="Economy">Economy</option>
                                            <option value="Standard">Standard</option>
                                            <option value="Deluxe">Deluxe</option>
                                            <option value="VIP">VIP</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Status</label>
                                        <select name="status" class="form-select" required>
                                            <option value="">-- Pilih Status --</option>
                                            <option value="tersedia">Tersedia</option>
                                            <option value="terisi">Terisi</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Fasilitas</label>
                                        <textarea name="fasilitas" class="form-control" rows="2" placeholder="Contoh: AC, WiFi, Kamar Mandi Dalam" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label>Alamat</label>
                                        <textarea name="alamat" class="form-control" rows="2" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label>Harga (Rp)</label>
                                        <input type="number" name="harga" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Deskripsi</label>
                                        <textarea name="deskripsi" class="form-control" rows="3" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label>Upload Gambar</label>
                                        <input type="file" name="gambar" class="form-control" accept="image/*" required>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i> Simpan</button>
                                        <a href="dasboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i> Kembali</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once 'template/footer.php'; ?>
    </div>
</div>