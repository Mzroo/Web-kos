<?php
session_start();
include '../config/koneksi.php';
$title = 'Konfirmasi Booking';
include_once 'template/header.php';
include_once 'template/navbar.php';
include_once 'template/slidebar.php';

// Ambil semua data booking
$query = mysqli_query($koneksi, "SELECT b.*, u.nama AS nama_user, k.nama_kamar 
    FROM booking b 
    JOIN user u ON b.id_user = u.id_user 
    JOIN kamar k ON b.id_kamar = k.id_kamar 
    ORDER BY b.id_booking DESC");
?>

<!-- Layout Content -->
<div id="layoutSidenav_content" class="d-flex flex-column min-vh-100">
    <main class="mb-5">
        <div class="container-fluid px-4">
            <h1 class="mt-1">Konfirmasi Booking</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard / Booking</li>
            </ol>
            <div class="card shadow mb-4">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-calendar-check me-2"></i>Data Booking Masuk</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle" style="font-size: 13px;">
                            <thead class="table-light text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Nama User</th>
                                    <th>Kamar</th>
                                    <th>Tanggal Masuk</th>
                                    <th>Durasi</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1;
                                while ($data = mysqli_fetch_assoc($query)) : ?>
                                    <tr>
                                        <td class="text-center"><?= $no++; ?></td>
                                        <td><?= htmlspecialchars($data['nama_user']); ?></td>
                                        <td><?= htmlspecialchars($data['nama_kamar']); ?></td>
                                        <td><?= htmlspecialchars($data['tanggal_masuk']); ?></td>
                                        <td><?= htmlspecialchars($data['durasi']); ?> bulan</td>
                                        <td class="text-center">
                                            <span class="badge bg-<?=
                                                                    $data['status'] == 'pending' ? 'warning text-dark' : ($data['status'] == 'diterima' ? 'success' : 'danger') ?>">
                                                <?= ucfirst($data['status']); ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <?php if ($data['status'] == 'pending') : ?>
                                                <a href="crud/konfirmasi_booking.php?id_booking=<?= $data['id_booking']; ?>&aksi=terima" class="btn btn-sm btn-success">
                                                    <i class="fas fa-check"></i> Terima
                                                </a>
                                                <a href="crud/konfirmasi_booking.php?id_booking=<?= $data['id_booking']; ?>&aksi=tolak" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menolak booking ini?')">
                                                    <i class="fas fa-times"></i> Tolak
                                                </a>
                                            <?php else : ?>
                                                <span class="text-muted">
                                                    <i class="fas fa-check-circle text-success"></i> <em>Terkonfirmasi</em>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                                <?php if (mysqli_num_rows($query) == 0): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Belum ada data booking.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= $main_url ?>admin/js/script.js"></script>