<?php
session_start();
include '../config/koneksi.php';

// Cek login
if (!isset($_SESSION['id_user'])) {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='../login.php';</script>";
    exit;
}

$id_kamar = $_GET['id'] ?? null;
if (!$id_kamar) {
    echo "ID kamar tidak ditemukan!";
    exit;
}

// Ambil data kamar
$kamar = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM kamar WHERE id_kamar = $id_kamar"));
if (!$kamar) {
    echo "Data kamar tidak tersedia!";
    exit;
}

// Cek ketersediaan
if ($kamar['status'] !== 'tersedia') {
    echo "<script>alert('Kamar sudah terisi!');window.location='dasboard.php';</script>";
    exit;
}

$pesan = "";
$alert = "";

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user = $_SESSION['id_user'];
    $tanggal_masuk = $_POST['tanggal_masuk'];
    $durasi = (int)$_POST['durasi'];
    $catatan = $_POST['catatan'];
    $harga = $kamar['harga'];
    $total_bayar = $durasi * $harga;

    if (strtotime($tanggal_masuk) < strtotime(date('Y-m-d'))) {
        $pesan = "Tanggal masuk tidak boleh di masa lalu!";
        $alert = "danger";
    } elseif ($durasi < 1) {
        $pesan = "Durasi minimal 1 bulan.";
        $alert = "danger";
    } else {
        // Simpan ke database
        $query = "INSERT INTO booking (
            id_user, id_kamar, tanggal_masuk, durasi, catatan, status, total_bayar
        ) VALUES (
            '$id_user', '$id_kamar', '$tanggal_masuk', '$durasi', '$catatan', 'pending', '$total_bayar'
        )";

        if (mysqli_query($koneksi, $query)) {
            echo "<script>alert('Booking berhasil! Menunggu konfirmasi admin.');window.location='dasboard.php';</script>";
            exit;
        } else {
            $pesan = "Gagal menyimpan booking.";
            $alert = "danger";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Booking</title>
    <link href="<?= $main_url ?>asset/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function updateTotal() {
            const harga = <?= $kamar['harga']; ?>;
            const durasi = document.getElementById('durasi').value;
            const total = harga * durasi;
            document.getElementById('totalBayar').innerText = isNaN(total) ? 'Rp 0' : 'Rp ' + total.toLocaleString('id-ID');
        }
    </script>
</head>

<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Booking Kamar: <?= htmlspecialchars($kamar['nama_kamar']); ?></h4>
                    </div>
                    <div class="card-body">
                        <p><strong>Harga per bulan:</strong> Rp <?= number_format($kamar['harga'], 0, ',', '.'); ?></p>

                        <?php if ($pesan): ?>
                            <div class="alert alert-<?= $alert; ?>"><?= $pesan; ?></div>
                        <?php endif; ?>

                        <form method="post">
                            <div class="mb-3">
                                <label for="tanggal_masuk" class="form-label">Tanggal Masuk</label>
                                <input type="date" name="tanggal_masuk" id="tanggal_masuk" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="durasi" class="form-label">Durasi (bulan)</label>
                                <input type="number" name="durasi" id="durasi" class="form-control" min="1" required oninput="updateTotal()">
                            </div>
                            <div class="mb-3">
                                <label for="catatan" class="form-label">Catatan (opsional)</label>
                                <textarea name="catatan" class="form-control" rows="3" placeholder="Tambahan informasi jika ada..."></textarea>
                            </div>
                            <div class="mb-3">
                                <label><strong>Total Bayar:</strong></label><br>
                                <span id="totalBayar" class="text-success fw-bold fs-5">Rp 0</span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <a href="detail.php?id=<?= $kamar['id_kamar']; ?>" class="btn btn-secondary">Kembali</a>
                                <button type="submit" class="btn btn-success">Kirim Booking</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>