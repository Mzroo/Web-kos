<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['id_user'])) {
    echo "<script>alert('Silakan login dahulu!'); window.location='../login.php';</script>";
    exit;
}

$id_user = $_SESSION['id_user'];
$id_booking = $_GET['id'] ?? null;

if (!$id_booking) {
    echo "ID booking tidak ditemukan!";
    exit;
}

// Ambil data booking milik user
$query = mysqli_query($koneksi, "SELECT b.*, k.nama_kamar FROM booking b 
JOIN kamar k ON b.id_kamar = k.id_kamar 
WHERE b.id_booking = '$id_booking' AND b.id_user = '$id_user'");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "<script>alert('Data booking tidak ditemukan!'); window.location='riwayat_booking.php';</script>";
    exit;
}

// Cek apakah booking disetujui
if ($data['status'] !== 'diterima') {
    echo "<script>alert('Bukti hanya bisa diunggah jika booking sudah diterima admin.'); window.location='riwayat_booking.php';</script>";
    exit;
}

$pesan = "";
$alert = "";

// Buat folder 'bukti' jika belum ada
if (!is_dir('bukti')) {
    mkdir('bukti', 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $metode = $_POST['metode'];
    $file = $_FILES['bukti'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png'];
    $nama_file = uniqid() . '.' . $ext;
    $path = 'bukti/' . $nama_file;

    if (!in_array($ext, $allowed)) {
        $pesan = "File harus berformat JPG atau PNG!";
        $alert = "danger";
    } elseif ($file['size'] > 2 * 1024 * 1024) {
        $pesan = "Ukuran maksimal 2MB.";
        $alert = "danger";
    } else {
        // Simpan file ke folder
        move_uploaded_file($file['tmp_name'], $path);

        // Update data booking
        mysqli_query($koneksi, "UPDATE booking SET 
    metode_pembayaran = '$metode',
    bukti_transfer = '$nama_file',
    status_pembayaran = 'pending'
    WHERE id_booking = '$id_booking'");


        echo "<script>alert('Bukti berhasil dikirim. Menunggu verifikasi admin.'); window.location='riwayat_booking.php';</script>";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Upload Bukti Pembayaran</title>
    <link href="<?= $main_url ?>asset/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= $main_url ?>asset/fontawesome/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .form-label {
            font-weight: 500;
        }

        .img-preview {
            max-width: 100%;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-top: 10px;
        }

        #infoRekening {
            background: #f1f1f1;
            padding: 12px;
            border-radius: 6px;
            font-weight: 500;
            display: none;
        }
    </style>
</head>

<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-md-9">
                <div class="card p-4">
                    <div class="card-body">
                        <h3 class="card-title text-center mb-4">Upload Bukti Pembayaran</h3>

                        <p><strong>Kamar:</strong> <?= htmlspecialchars($data['nama_kamar']); ?></p>
                        <p><strong>Total Bayar:</strong> Rp <?= number_format($data['total_bayar'], 0, ',', '.'); ?></p>

                        <?php if ($pesan): ?>
                            <div class="alert alert-<?= $alert; ?>"><?= $pesan; ?></div>
                        <?php endif; ?>

                        <?php if (!empty($data['bukti_transfer'])): ?>
                            <div class="mb-3">
                                <label class="form-label">Bukti Pembayaran Sebelumnya:</label><br>
                                <img src="bukti/<?= htmlspecialchars($data['bukti_transfer']); ?>" alt="Bukti Pembayaran" class="img-preview">
                            </div>
                        <?php endif; ?>

                        <form method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="metode" class="form-label">Metode Pembayaran</label>
                                <select name="metode" id="metode" class="form-select" required onchange="tampilkanRekening()">
                                    <option value="">-- Pilih Metode --</option>
                                    <option value="Transfer Bank">Transfer Bank</option>
                                    <option value="OVO">OVO</option>
                                    <option value="Dana">Dana</option>
                                    <option value="Gopay">Gopay</option>
                                </select>
                            </div>

                            <div id="infoRekening" class="mb-3"></div>

                            <div class="mb-3">
                                <label for="bukti" class="form-label">Upload Bukti Pembayaran (JPG/PNG, Max 2MB)</label>
                                <input type="file" name="bukti" id="bukti" class="form-control" accept=".jpg,.jpeg,.png" required>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success">Upload Sekarang</button>
                                <a href="riwayat_booking.php" class="btn btn-outline-secondary">Kembali ke Riwayat</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function tampilkanRekening() {
            const metode = document.getElementById("metode").value;
            const infoRek = document.getElementById("infoRekening");

            let pesan = "";

            switch (metode) {
                case "Transfer Bank":
                    pesan = "Transfer ke Rekening BCA 1234567890 a.n. Kos Aman Sejahtera";
                    break;
                case "OVO":
                    pesan = "Kirim ke OVO: 0812-3456-7890 a.n. Admin Kos";
                    break;
                case "Dana":
                    pesan = "Kirim ke Dana: 0856-1234-5678 a.n. Admin Kos";
                    break;
                case "Gopay":
                    pesan = "Kirim ke Gopay: 0822-9876-5432 a.n. Admin Kos";
                    break;
                default:
                    infoRek.style.display = "none";
                    return;
            }

            infoRek.innerText = pesan;
            infoRek.style.display = "block";
        }
    </script>

    <script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>