<?php
include '../../config/koneksi.php';
$title = 'Profile User';
include_once '../../template/header.php';

// Cek apakah user sudah login
session_start();
if (!isset($_SESSION['id_user'])) {
    header('Location: ../../login.php');
    exit;
}
$user_id = $_SESSION['id_user'];
$query = mysqli_query($koneksi, "SELECT * FROM user WHERE id_user = '$user_id'");
$user = mysqli_fetch_assoc($query);
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="list-group">
                <a href="profil.php" class="list-group-item list-group-item-action active">Profil Saya</a>
                <a href="<?= $main_url ?>user/riwayat_booking.php" class="list-group-item list-group-item-action">Riwayat Booking</a>
                <a href="#" class="list-group-item list-group-item-action">Status Sewa Aktif</a>
                <a href="#" class="list-group-item list-group-item-action">Edit Profil</a>
                <a href="#" class="list-group-item list-group-item-action">Ubah Password</a>
                <a href="<?= $main_url ?>config/logout.php" class="list-group-item list-group-item-action text-danger">Logout</a>
            </div>
        </div>

        <!-- Content -->
        <div class="col-md-9">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Informasi Akun</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th>Nama Lengkap</th>
                            <td><?= htmlspecialchars($user['nama']); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= htmlspecialchars($user['email']); ?></td>
                        </tr>
                        <!-- <tr>
                            <th>No HP</th>
                            <td><?= htmlspecialchars($user['no_hp']); ?></td>
                        </tr> -->
                        <!-- <tr>
                            <th>Jenis Kelamin</th>
                            <td><?= htmlspecialchars($user['jenis_kelamin']); ?></td>
                        </tr> -->
                    </table>
                    <!-- <a href="edit_profil.php" class="btn btn-outline-primary">Edit Profil</a>
                    <a href="ubah_password.php" class="btn btn-outline-secondary">Ubah Password</a> -->
                </div>
            </div>
        </div>
    </div>
</div>