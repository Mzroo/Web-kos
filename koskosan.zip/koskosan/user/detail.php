<?php
include '../config/koneksi.php';
include_once '../template/header.php';

if (!isset($_GET['id'])) {
    echo "ID kamar tidak ditemukan!";
    exit;
}

$id_kamar = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM kamar WHERE id_kamar = $id_kamar");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "Data kamar tidak tersedia.";
    exit;
}
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4 mb-4">
            <div class="card shadow h-100">
                <img src="../img/<?= htmlspecialchars($data['gambar']); ?>" class="card-img-top" alt="<?= htmlspecialchars($data['nama_kamar']); ?>" style="height: 200px; object-fit: cover;">

                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?= htmlspecialchars($data['nama_kamar']); ?></h5>
                    <p class="card-text flex-grow-1"><?= nl2br(htmlspecialchars(substr($data['deskripsi'], 0, 100))) . '...'; ?></p>

                    <div class="d-flex gap-2 mb-2 flex-wrap">
                        <span class="badge bg-secondary"><?= htmlspecialchars($data['jenis_kos']); ?></span>
                        <span class="badge bg-info"><?= htmlspecialchars($data['tipe_kamar']); ?></span>
                        <span class="badge bg-success"><?= htmlspecialchars($data['status']); ?></span>
                    </div>

                    <p class="text-primary fw-bold">Rp <?= number_format($data['harga'], 0, ',', '.'); ?>/bulan</p>

                    <?php if ($data['status'] === 'tersedia'): ?>
                        <a href="booking.php?id=<?= $data['id_kamar']; ?>" class="btn btn-success w-100 mb-2">Booking Sekarang</a>
                    <?php else: ?>
                        <div class="alert alert-danger text-center p-1">Kamar sudah terisi</div>
                    <?php endif; ?>

                    <a href="dasboard.php" class="btn btn-outline-secondary w-100">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>