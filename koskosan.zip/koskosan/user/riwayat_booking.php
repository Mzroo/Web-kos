<?php
include_once '../config/koneksi.php';
$title = 'Riwayat Booking';
include_once '../template/header.php';
include_once 'template/navbar.php';
session_start();

// Cek login
if (!isset($_SESSION['id_user'])) {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='../login.php';</script>";
    exit;
}

$id_user = $_SESSION['id_user'];
$query = mysqli_query($koneksi, "
    SELECT b.*, k.nama_kamar 
    FROM booking b 
    JOIN kamar k ON b.id_kamar = k.id_kamar 
    WHERE b.id_user = $id_user 
    ORDER BY b.id_booking DESC
");
?>
<div class="container py-5 " style="margin-top: 100px;">
    <div class="card shadow border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">
                <i class="fas fa-history me-2"></i> Riwayat Booking Anda
            </h4>
        </div>

        <div class="card-body table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Nama Kamar</th>
                        <th>Tanggal Masuk</th>
                        <th>Durasi</th>
                        <th>Total Bayar</th>
                        <th>Status Booking</th>
                        <th>Status Pembayaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php while ($data = mysqli_fetch_assoc($query)) : ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= htmlspecialchars($data['nama_kamar']); ?></td>
                            <td><?= date("d M Y", strtotime($data['tanggal_masuk'])); ?></td>
                            <td><?= $data['durasi']; ?> bulan</td>
                            <td>Rp <?= number_format($data['total_bayar'], 0, ',', '.'); ?></td>
                            <td>
                                <?php
                                $status = $data['status'];
                                $badgeColor = $status === 'pending' ? 'warning' : ($status === 'diterima' ? 'success' : 'danger');
                                $icon = $status === 'pending' ? 'clock' : ($status === 'diterima' ? 'check' : 'times');
                                ?>
                                <span class="badge bg-<?= $badgeColor; ?>">
                                    <i class="fas fa-<?= $icon; ?>"></i> <?= ucfirst($status); ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                $pembayaran = $data['status_pembayaran'] ?? 'belum bayar';

                                if ($pembayaran === 'sudah bayar') {
                                    $badgePembayaran = 'success';
                                    $iconPembayaran = 'check-circle';
                                } elseif ($pembayaran === 'pending') {
                                    $badgePembayaran = 'warning';
                                    $iconPembayaran = 'clock';
                                } else {
                                    $badgePembayaran = 'secondary';
                                    $iconPembayaran = 'exclamation-circle';
                                    $pembayaran = 'belum bayar';
                                }
                                ?>
                                <span class="badge bg-<?= $badgePembayaran; ?>">
                                    <i class="fas fa-<?= $iconPembayaran; ?>"></i>
                                    <?= ucfirst($pembayaran); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($status === 'diterima' && $pembayaran !== 'sudah bayar') : ?>
                                    <a href="upload_bukti.php?id=<?= $data['id_booking']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-upload"></i> Upload
                                    </a>
                                <?php elseif ($pembayaran === 'sudah bayar') : ?>
                                    <a href="bukti/<?= $data['bukti_transfer']; ?>" target="_blank" class="btn btn-sm btn-success">
                                        <i class="fas fa-eye"></i> Lihat Bukti
                                    </a>
                                <?php else : ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="<?= $main_url ?>asset/bootstrap/js/bootstrap.bundle.min.js"></script>