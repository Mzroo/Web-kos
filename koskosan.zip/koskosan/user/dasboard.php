<?php
session_start();
include_once '../config/koneksi.php';
$title = "Dasboard User";
include_once '../template/header.php';
include_once 'template/navbar.php';
include_once 'template/header.php';
?>

<body>

    <!-- KAMAR PUTRA -->
    <section class="py-5 section-2-index shadow" id="kamar-putra kamar">
        <div class="container">
            <h2 class="text-center mb-5">Daftar Kamar Kos</h2>

            <?php
            $jenis_kos = ['Putra']; // Bisa ditambah 'Putri', 'Campuran', dst.

            foreach ($jenis_kos as $jenis) {
                echo "<h4 class='mb-4'>$jenis</h4>";

                $per_page = 3;
                $page_key = "page_" . strtolower($jenis); // contoh: page_putra
                $page = isset($_GET[$page_key]) ? (int)$_GET[$page_key] : 1;
                $start = ($page - 1) * $per_page;

                // Ambil data kamar sesuai jenis dan halaman
                $query = "SELECT * FROM kamar WHERE jenis_kos = '$jenis' LIMIT $start, $per_page";
                $result = mysqli_query($koneksi, $query);

                // Hitung total kamar
                $total_query = "SELECT COUNT(*) as total FROM kamar WHERE jenis_kos = '$jenis'";
                $total_result = mysqli_query($koneksi, $total_query);
                $total_data = mysqli_fetch_assoc($total_result)['total'];
                $total_pages = ceil($total_data / $per_page);

                if (mysqli_num_rows($result) > 0) {
                    echo "<div class='row'>";
                    while ($data = mysqli_fetch_assoc($result)) {
                        echo "
                    <div class='col-md-4 mb-4'>
                        <div class='card shadow h-100'>
                            <img src='../img/{$data['gambar']}' class='card-img-top' alt='{$data['nama_kamar']}' style='height:200px; object-fit:cover;'>
                        <div class='card-body d-flex flex-column'>
                    <h5 class='card-title'>{$data['nama_kamar']}</h5>
                    <p class='card-text flex-grow-1'>{$data['deskripsi']}</p>
                    <div class='d-flex gap-2 mb-2 flex-wrap'>
                        <span class='badge bg-secondary'>{$data['jenis_kos']}</span>
                        <span class='badge bg-info'>{$data['fasilitas']}</span>
                        <span class='badge bg-success'>{$data['status']}</span>
                    </div>
                    <p class='text-primary fw-bold'>Rp " . number_format($data['harga'], 0, ',', '.') . "/bulan</p>
                    <a href='detail.php?id={$data['id_kamar']}' class='btn btn-primary mt-auto'>Lihat Detail</a>
                </div>
            </div>
        </div>";
                    }
                    echo "</div>";

                    // Pagination
                    if ($total_pages > 1) {
                        echo '<nav aria-label="Page navigation" class="mt-4"><ul class="pagination justify-content-center">';

                        // Tombol sebelumnya
                        if ($page > 1) {
                            $prev = $page - 1;
                            echo "<li class='page-item'><a class='page-link' href='?{$page_key}=$prev'>&laquo;</a></li>";
                        }

                        // Nomor halaman
                        for ($i = 1; $i <= $total_pages; $i++) {
                            $active = ($i == $page) ? 'active' : '';
                            echo "<li class='page-item $active'><a class='page-link' href='?{$page_key}=$i'>$i</a></li>";
                        }

                        // Tombol berikutnya
                        if ($page < $total_pages) {
                            $next = $page + 1;
                            echo "<li class='page-item'><a class='page-link' href='?{$page_key}=$next'>&raquo;</a></li>";
                        }

                        echo '</ul></nav>';
                    }
                } else {
                    echo "<p class='text-muted'>Belum ada kamar untuk kos $jenis.</p><hr class='my-5'>";
                }
            }
            ?>
        </div>
    </section>

    <!-- KAMAR PUTRI -->
    <section class="py-5 section-4" id="kamar-putri">
        <div class="container">
            <?php
            $jenis_kos = ['Putri']; // Bisa ditambah 'Putri', 'Campuran', dst.

            foreach ($jenis_kos as $jenis) {
                echo "<h4 class='mb-4'>$jenis</h4>";

                $per_page = 3;
                $page_key = "page_" . strtolower($jenis); // contoh: page_putra
                $page = isset($_GET[$page_key]) ? (int)$_GET[$page_key] : 1;
                $start = ($page - 1) * $per_page;

                // Ambil data kamar sesuai jenis dan halaman
                $query = "SELECT * FROM kamar WHERE jenis_kos = '$jenis' LIMIT $start, $per_page";
                $result = mysqli_query($koneksi, $query);

                // Hitung total kamar
                $total_query = "SELECT COUNT(*) as total FROM kamar WHERE jenis_kos = '$jenis'";
                $total_result = mysqli_query($koneksi, $total_query);
                $total_data = mysqli_fetch_assoc($total_result)['total'];
                $total_pages = ceil($total_data / $per_page);

                if (mysqli_num_rows($result) > 0) {
                    echo "<div class='row'>";
                    while ($data = mysqli_fetch_assoc($result)) {
                        echo "
                <div class='col-md-4 mb-4'>
            <div class='card shadow h-100'>
                <img src='../img/{$data['gambar']}' class='card-img-top' alt='{$data['nama_kamar']}' style='height:200px; object-fit:cover;'>
                <div class='card-body d-flex flex-column'>
                    <h5 class='card-title'>{$data['nama_kamar']}</h5>
                    <p class='card-text flex-grow-1'>{$data['deskripsi']}</p>
                    <div class='d-flex gap-2 mb-2 flex-wrap'>
                        <span class='badge bg-secondary'>{$data['jenis_kos']}</span>
                        <span class='badge bg-info'>{$data['fasilitas']}</span>
                        <span class='badge bg-success'>{$data['status']}</span>
                    </div>
                    <p class='text-primary fw-bold'>Rp " . number_format($data['harga'], 0, ',', '.') . "/bulan</p>
                    <a href='detail.php?id={$data['id_kamar']}' class='btn btn-primary mt-auto'>Lihat Detail</a>
                </div>
            </div>
        </div>";
                    }
                    echo "</div>";

                    // Pagination
                    if ($total_pages > 1) {
                        echo '<nav aria-label="Page navigation" class="mt-4"><ul class="pagination justify-content-center">';

                        // Tombol sebelumnya
                        if ($page > 1) {
                            $prev = $page - 1;
                            echo "<li class='page-item'><a class='page-link' href='?{$page_key}=$prev'>&laquo;</a></li>";
                        }

                        // Nomor halaman
                        for ($i = 1; $i <= $total_pages; $i++) {
                            $active = ($i == $page) ? 'active' : '';
                            echo "<li class='page-item $active'><a class='page-link' href='?{$page_key}=$i'>$i</a></li>";
                        }

                        // Tombol berikutnya
                        if ($page < $total_pages) {
                            $next = $page + 1;
                            echo "<li class='page-item'><a class='page-link' href='?{$page_key}=$next'>&raquo;</a></li>";
                        }

                        echo '</ul></nav>';
                    }
                } else {
                    echo "<p class='text-muted'>Belum ada kamar untuk kos $jenis.</p><hr class='my-5'>";
                }
            }
            ?>
        </div>
    </section>

    <!-- KAMAR CAMPURAN -->
    <section class="py-5 section-kontak" id="kamar-campuran">
        <div class="container">

            <?php
            $jenis_kos = ['Campuran']; // Bisa ditambah 'Putri', 'Campuran', dst.

            foreach ($jenis_kos as $jenis) {
                echo "<h4 class='mb-4'>$jenis</h4>";

                $per_page = 3;
                $page_key = "page_" . strtolower($jenis); // contoh: page_putra
                $page = isset($_GET[$page_key]) ? (int)$_GET[$page_key] : 1;
                $start = ($page - 1) * $per_page;

                // Ambil data kamar sesuai jenis dan halaman
                $query = "SELECT * FROM kamar WHERE jenis_kos = '$jenis' LIMIT $start, $per_page";
                $result = mysqli_query($koneksi, $query);

                // Hitung total kamar
                $total_query = "SELECT COUNT(*) as total FROM kamar WHERE jenis_kos = '$jenis'";
                $total_result = mysqli_query($koneksi, $total_query);
                $total_data = mysqli_fetch_assoc($total_result)['total'];
                $total_pages = ceil($total_data / $per_page);

                if (mysqli_num_rows($result) > 0) {
                    echo "<div class='row'>";
                    while ($data = mysqli_fetch_assoc($result)) {
                        echo "
           <div class='col-md-4 mb-4'>
            <div class='card shadow h-100'>
                <img src='../img/{$data['gambar']}' class='card-img-top' alt='{$data['nama_kamar']}' style='height:200px; object-fit:cover;'>
                <div class='card-body d-flex flex-column'>
                    <h5 class='card-title'>{$data['nama_kamar']}</h5>
                    <p class='card-text flex-grow-1'>{$data['deskripsi']}</p>
                    <div class='d-flex gap-2 mb-2 flex-wrap'>
                        <span class='badge bg-secondary'>{$data['jenis_kos']}</span>
                        <span class='badge bg-info'>{$data['fasilitas']}</span>
                        <span class='badge bg-success'>{$data['status']}</span>
                    </div>
                    <p class='text-primary fw-bold'>Rp " . number_format($data['harga'], 0, ',', '.') . "/bulan</p>
                    <a href='detail.php?id={$data['id_kamar']}' class='btn btn-primary mt-auto'>Lihat Detail</a>
                </div>
            </div>
        </div>";
                    }
                    echo "</div>";

                    // Pagination
                    if ($total_pages > 1) {
                        echo '<nav aria-label="Page navigation" class="mt-4"><ul class="pagination justify-content-center">';

                        // Tombol sebelumnya
                        if ($page > 1) {
                            $prev = $page - 1;
                            echo "<li class='page-item'><a class='page-link' href='?{$page_key}=$prev'>&laquo;</a></li>";
                        }

                        // Nomor halaman
                        for ($i = 1; $i <= $total_pages; $i++) {
                            $active = ($i == $page) ? 'active' : '';
                            echo "<li class='page-item $active'><a class='page-link' href='?{$page_key}=$i'>$i</a></li>";
                        }

                        // Tombol berikutnya
                        if ($page < $total_pages) {
                            $next = $page + 1;
                            echo "<li class='page-item'><a class='page-link' href='?{$page_key}=$next'>&raquo;</a></li>";
                        }

                        echo '</ul></nav>';
                    }
                } else {
                    echo "<p class='text-muted'>Belum ada kamar untuk kos $jenis.</p><hr class='my-5'>";
                }
            }
            ?>
        </div>
    </section>
</body>
<?php
include_once '../template/kontak.php';
include_once '../template/footer.php';
?>