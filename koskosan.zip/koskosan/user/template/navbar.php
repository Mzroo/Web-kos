<?php
// session_start();
$nama_user = $_SESSION['nama'] ?? 'User';
?>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-dark navbar-dark fixed-top py-4 shadow" style="min-height: 60px;">
    <div class="container">
        <a href="<?= $main_url ?>user/dasboard.php" class="navbar-brand d-flex align-items-center">
            <img src="<?= $main_url ?>asset/img/Logo.png" alt="Logo Kos Ku" style="height:80px; margin-top:-20px; margin-bottom:-20px;">
        </a>


        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownKamar" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-solid fa-bed"></i> Kamar
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownKamar">
                        <li><a class="dropdown-item" href="<?= $main_url ?>user/dasboard.php#kamar-putra">Kamar Putra</a></li>
                        <li><a class="dropdown-item" href="<?= $main_url ?>user/dasboard.php#kamar-putri">Kamar Putri</a></li>
                        <li><a class="dropdown-item" href="<?= $main_url ?>user/dasboard.php#kamar-campuran">Kamar Campuran</a></li>
                    </ul>

                </li>


            </ul>

            <!-- Search + user -->
            <div class="d-flex align-items-center">
                <!-- Search Form -->
                <form class="d-flex me-3" method="GET" action="<?= $main_url ?>user/kamar.php">
                    <input class="form-control form-control-sm me-2" type="search" name="cari" placeholder="Cari kamar..." aria-label="Search">
                    <button class="btn btn-outline-light btn-sm" type="submit">Cari</button>
                </form>

                <!-- User Dropdown -->
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center text-white" href="#" role="button" data-bs-toggle="dropdown">
                        <img src="<?= $main_url ?>asset/img/user.png" alt="User" width="30" class="rounded-circle me-2">
                        <?= htmlspecialchars($nama_user); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?= $main_url ?>user/profile/profile.php">Profil Saya</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item text-danger" href="<?= $main_url ?>config/logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>