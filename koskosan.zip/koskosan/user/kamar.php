<?php
session_start();
include_once '../config/koneksi.php';

$title = "Dashboard Kamar";
include_once '../template/header.php';
include_once 'template/navbar.php';
include_once 'template/header.php';

// Ambil keyword pencarian dari URL
$search = isset($_GET['cari']) ? mysqli_real_escape_string($koneksi, $_GET['cari']) : '';

// Pagination setup
$limit = 6;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Hitung total data
$count_query = "SELECT COUNT(*) AS total FROM kamar";
if (!empty($search)) {
  $count_query .= " WHERE nama_kamar LIKE '%$search%' 
                    OR jenis_kos LIKE '%$search%' 
                    OR tipe_kamar LIKE '%$search%'";
}
$count_result = mysqli_query($koneksi, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_data / $limit);

// Ambil data kamar
$query = "SELECT * FROM kamar";
if (!empty($search)) {
  $query .= " WHERE nama_kamar LIKE '%$search%' 
              OR jenis_kos LIKE '%$search%' 
              OR tipe_kamar LIKE '%$search%'";
}
$query .= " ORDER BY id_kamar DESC LIMIT $start, $limit";
$result = mysqli_query($koneksi, $query);
?>

<div class="container mt-4 mb-5">
  <h4 class="mb-3">Daftar Kamar</h4>

  <?php if (!empty($search)): ?>
    <p class="text-muted">Hasil pencarian untuk: <strong><?= htmlspecialchars($search) ?></strong></p>
  <?php endif; ?>

  <div class="row">
    <?php if (mysqli_num_rows($result) > 0): ?>
      <?php while ($data = mysqli_fetch_assoc($result)): ?>
        <div class="col-md-4 mb-4">
          <div class="card shadow h-100">
            <img src="../img/<?= $data['gambar'] ?>" class="card-img-top" alt="<?= htmlspecialchars($data['nama_kamar']) ?>" style="height: 200px; object-fit: cover;">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?= htmlspecialchars($data['nama_kamar']) ?></h5>
              <p class="card-text flex-grow-1"><?= htmlspecialchars($data['deskripsi']) ?></p>
              <div class="d-flex gap-2 mb-2 flex-wrap">
                <span class="badge bg-secondary"><?= htmlspecialchars($data['jenis_kos']) ?></span>
                <span class="badge bg-info"><?= htmlspecialchars($data['fasilitas']) ?></span>
                <span class="badge bg-<?= $data['status'] === 'tersedia' ? 'success' : 'danger' ?>">
                  <?= htmlspecialchars($data['status']) ?>
                </span>
              </div>
              <p class="text-primary fw-bold">Rp <?= number_format($data['harga'], 0, ',', '.') ?>/bulan</p>
              <a href="detail.php?id=<?= $data['id_kamar'] ?>" class="btn btn-primary mt-auto">Lihat Detail</a>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <div class="col-12">
        <div class="alert alert-warning text-center">Data kamar tidak ditemukan.</div>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($total_pages > 1): ?>
    <nav aria-label="Pagination" class="mt-4">
      <ul class="pagination justify-content-center">
        <?php if ($page > 1): ?>
          <li class="page-item">
            <a class="page-link" href="?cari=<?= urlencode($search) ?>&page=<?= $page - 1 ?>">&laquo; Sebelumnya</a>
          </li>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
          <li class="page-item <?= $i == $page ? 'active' : '' ?>">
            <a class="page-link" href="?cari=<?= urlencode($search) ?>&page=<?= $i ?>"><?= $i ?></a>
          </li>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
          <li class="page-item">
            <a class="page-link" href="?cari=<?= urlencode($search) ?>&page=<?= $page + 1 ?>">Berikutnya &raquo;</a>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  <?php endif; ?>
</div>

<?php include_once '../template/footer.php'; ?>