<?php
session_start();
include 'koneksi.php';

$email = $_POST['email'];
$password = $_POST['password'];

// Ambil data user berdasarkan email saja
$query = "SELECT * FROM user WHERE email = '$email'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if ($data) {
    // Cocokkan password yang diinput dengan password hash di database
    if (password_verify($password, $data['password'])) {
        // Set session login
        $_SESSION['id_user'] = $data['id_user'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['email'] = $data['email'];
        $_SESSION['role'] = $data['role'];

        // Redirect sesuai role
        if ($data['role'] == 'admin') {
            header("Location: ../admin/dasboard.php");
        } elseif ($data['role'] == 'user') {
            header("Location: ../user/dasboard.php");
        } else {
            echo "Role tidak dikenali.";
        }
    } else {
        echo "<script>alert('Password salah!'); window.location='../login.php';</script>";
    }
} else {
    echo "<script>alert('Email tidak ditemukan!'); window.location='../login.php';</script>";
}
