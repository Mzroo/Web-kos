<?php

$koneksi = mysqli_connect('localhost', 'root', '', 'db_kos');


$main_url = "http://localhost/koskosan/";
