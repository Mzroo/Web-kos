<?php
session_start();         // Mulai session
session_unset();         // Hapus semua data session
session_destroy();       // Hancurkan session

header("location: ../index.php");  // Redirect ke halaman login
exit();
