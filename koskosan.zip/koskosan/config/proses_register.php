<?php
include("koneksi.php");

if ($_SERVER['REQUEST_METHOD']  == "POST") {
    $name     = $_POST['nama'];
    $email    = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Enkripsi password

    $query = "INSERT INTO user (nama, email, password, role) 
              VALUES ('$name', '$email', '$password', 'user')"; // default role: user

    $result = mysqli_query($koneksi, $query);
    if ($result) {
        echo "<script>alert('Registrasi berhasil! Silakan login.'); window.location='../login.php';</script>";
    } else {
        echo "<script>alert('Registrasi gagal! Email mungkin sudah digunakan.'); window.location='../register.php';</script>";
    }
}
