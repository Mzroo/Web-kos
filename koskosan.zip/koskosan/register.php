<?php
include_once 'config/koneksi.php';
$title = "From - Login";
include_once 'template/header.php';

?>

<body>
    <div class="background-img">
        <div class="login-container">
            <h3 class="text-center mb-4">MENU REGISTER</h3>
            <form action="config/proses_register.php" method="post">
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" required autofocus>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Contoh@gmail.com" required autofocus>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Register</button>
            </form>

            <div class="text-center mt-3">
                <p>Sudah Punya Akun? <a href="login.php">Login</a></p>
            </div>
        </div>
    </div>

    <script src="asset/boostrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>