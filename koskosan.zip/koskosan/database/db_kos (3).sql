-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2025 at 06:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kos`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id_booking` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_kamar` int(11) DEFAULT NULL,
  `tanggal_booking` datetime DEFAULT current_timestamp(),
  `tanggal_masuk` date DEFAULT NULL,
  `durasi` int(11) DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `status` enum('pending','diterima','ditolak') DEFAULT 'pending',
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `bukti_transfer` varchar(255) DEFAULT NULL,
  `status_pembayaran` enum('belum bayar','pending','sudah bayar') DEFAULT 'belum bayar',
  `total_bayar` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kamar`
--

CREATE TABLE `kamar` (
  `id_kamar` int(11) NOT NULL,
  `nama_kamar` varchar(100) NOT NULL,
  `jenis_kos` enum('Putra','Putri','Campuran') NOT NULL,
  `tipe_kamar` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `harga` int(11) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `fasilitas` text DEFAULT NULL,
  `status` enum('tersedia','terisi') DEFAULT 'tersedia',
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kamar`
--

INSERT INTO `kamar` (`id_kamar`, `nama_kamar`, `jenis_kos`, `tipe_kamar`, `alamat`, `harga`, `deskripsi`, `fasilitas`, `status`, `gambar`) VALUES
(14, 'Lavender 01', 'Campuran', 'Economy', ' Jl. Melati No. 12, Bandung', 1200000, 'Kamar nyaman untuk 1-2 orang, cocok untuk mahasiswa atau pekerja.', ' AC, WiFi, Kamar Mandi Dalam, Lemari, Meja Belajar', 'tersedia', 'gambar5.jfif'),
(15, ' Garuda A3', 'Putra', 'Single', 'Jl. Kopo No. 7, Bandung', 850000, 'Lokasi strategis dekat kampus, nyaman dan tenang.\r\n\r\n', 'WiFi, Meja Belajar, Lemari, Dapur Bersama', 'tersedia', 'gambar10.jfif'),
(16, 'Mawar 5', 'Putri', 'Deluxe', 'Jl. Cibaduyut No. 21, Bandung', 1300000, 'Aman dan nyaman untuk mahasiswi, tersedia ruang tamu bersama.', 'AC, WiFi, Meja Belajar, Cermin, Lemari, Laundry', 'tersedia', 'kamar.jpg'),
(17, 'Orchid Room 2', 'Campuran', 'Single', 'Jl. Soekarno Hatta No. 45, Bandung', 900000, 'Kamar bersih dan nyaman, dekat fasilitas umum.', 'WiFi, Lemari, Dapur Bersama, Parkir Motor', 'tersedia', 'gambar9.jfif'),
(18, 'Merapi 01', 'Putra', 'Single', ' Jl. Asia Afrika No. 10, Bandung', 1100000, 'Kamar modern dengan fasilitas lengkap, akses 24 jam.', 'AC, Meja Belajar, Kasur, Lemari', 'tersedia', 'gambar11.jfif'),
(19, 'Sakura 7', 'Putri', 'Single', 'Jl. Dipatiukur No. 33, Bandung', 950000, 'Didesain untuk kenyamanan dan privasi mahasiswi.', 'WiFi, Lemari, Cermin, Akses Dapur, Laundry', 'tersedia', 'gambar4.jfif'),
(20, 'Anggrek 2', 'Campuran', 'Single', 'Jl. Cihampelas No. 89, Bandung', 1400000, 'Kamar eksklusif di pusat kota, akses mudah ke mall dan transportasi umum', 'AC, WiFi, Lemari, Meja Belajar, Water Heater', 'tersedia', 'gambar11.jfif'),
(21, 'Cemara 8', 'Putra', 'Economy', ' Jl. Pasteur No. 14, Bandung', 800000, 'Nyaman untuk mahasiswa, lingkungan aman dan dekat kampus.', 'Meja Belajar, Lemari, WiFi, Dapur Bersama', 'tersedia', 'gambar12.jfif'),
(22, 'Melati 3', 'Putri', 'Suite', 'Jl. Surapati No. 17, Bandung', 1250000, 'Kamar bersih dan nyaman, cocok untuk mahasiswi atau karyawan.', 'AC, WiFi, Lemari, Cermin, Dapur Mini, Laundry', 'tersedia', 'gambar8.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `email`, `password`, `role`) VALUES
(3, 'iyan', 'iyan@gmail.com', '$2y$10$vaDgT634dPej56LuXNyiHOZv6wYk03QN8ZUvULXYMtD5DZHoSpJxK', 'user'),
(4, 'admin', 'admin@gmail.com', '$2y$10$4eaCy2eUpWdMVaJs65t2bOZ.P4.5b65olJua7WxAbsYZp3UUVdby6', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id_booking`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_kamar` (`id_kamar`);

--
-- Indexes for table `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id_booking` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `kamar`
--
ALTER TABLE `kamar`
  MODIFY `id_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE,
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`id_kamar`) REFERENCES `kamar` (`id_kamar`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
