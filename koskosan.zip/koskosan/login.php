<?php
include_once 'config/koneksi.php';
$title = "From - Login";
include_once 'template/header.php';

?>

<body>
    <div class="background-img">
        <div class="login-container">
            <h3 class="text-center mb-4">MENU LOGIN</h3>
            <form action="config/proses_login.php" method="post">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="email" class="form-control" id="email" name="email" required autofocus placeholder="Username@gmail.com">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>

            <div class="text-center mt-3">
                <p>Belum punya akun? <a href="register.php">Register</a></p>
            </div>
        </div>
    </div>

    <script src="asset/boostrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>